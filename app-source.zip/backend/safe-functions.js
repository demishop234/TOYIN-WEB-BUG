'use strict';
const MAX_TEXT_LENGTH = 4000;
const MIN_SEND_INTERVAL_MS = 1500;
const lastSentAt = new Map();

function normalizeTarget(value) {
  const raw = String(value || '').trim();
  if (/^\d{5,25}-\d{5,25}@g\.us$/.test(raw)) return raw;
  const number = raw.replace(/@s\.whatsapp\.net$/i, '').replace(/[+\s()-]/g, '');
  if (!/^\d{7,15}$/.test(number)) throw new Error('Enter a valid phone number or group JID.');
  return `${number}@s.whatsapp.net`;
}
async function sendSafeText(sock, target, text) {
  if (!sock || typeof sock.sendMessage !== 'function') throw new Error('WhatsApp session is disconnected.');
  const body = String(text ?? '').trim();
  if (!body || body.length > MAX_TEXT_LENGTH) throw new Error(`Text must contain 1-${MAX_TEXT_LENGTH} characters.`);
  const jid = normalizeTarget(target);
  const now = Date.now();
  const previous = lastSentAt.get(jid) || 0;
  if (now - previous < MIN_SEND_INTERVAL_MS) throw new Error('Please wait before sending another message to this target.');
  lastSentAt.set(jid, now);
  try { return await sock.sendMessage(jid, { text: body }); }
  catch (error) { if (lastSentAt.get(jid) === now) lastSentAt.delete(jid); throw error; }
}
module.exports = { normalizeTarget, sendSafeText };
