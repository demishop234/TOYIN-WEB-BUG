'use strict';
const jwt = require('jsonwebtoken');
const { pool } = require('./db');

function signToken(user) {
  return jwt.sign(
    { sub: String(user.id), username: user.username, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: '12h', issuer: 't-inverted', audience: 't-inverted-web' }
  );
}

async function requireAuth(req, res, next) {
  try {
    const bearer = (req.get('authorization') || '').match(/^Bearer\s+(.+)$/i);
    const token = req.cookies?.ti_session || bearer?.[1];
    if (!token) return res.status(401).json({ error: 'Please log in.' });
    const payload = jwt.verify(token, process.env.JWT_SECRET, {
      issuer: 't-inverted', audience: 't-inverted-web'
    });
    const result = await pool.query(
      'SELECT id, username, role, status, telegram_id FROM users WHERE id = $1',
      [payload.sub]
    );
    const user = result.rows[0];
    if (!user || user.status !== 'active') return res.status(401).json({ error: 'Account unavailable.' });
    req.user = user;
    next();
  } catch (_error) {
    return res.status(401).json({ error: 'Session expired. Please log in again.' });
  }
}

function requireAdmin(req, res, next) {
  if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Administrator access required.' });
  next();
}

function setSessionCookie(res, token) {
  res.cookie('ti_session', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 12 * 60 * 60 * 1000
  });
}

module.exports = { signToken, requireAuth, requireAdmin, setSessionCookie };
