'use strict';
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const path = require('path');
const { pool, initDb } = require('./db');
const { signToken, requireAuth, requireAdmin, setSessionCookie } = require('./auth');
const { sendSafeText } = require('./safe-functions');

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 64 ||
    !(process.env.OWNER_USERNAME || process.env.ADMIN_USERNAME) || !process.env.ADMIN_PASSWORD ||
    process.env.ADMIN_PASSWORD.length < 14) {
  throw new Error('Set JWT_SECRET (64+ chars), OWNER_USERNAME (or ADMIN_USERNAME), and ADMIN_PASSWORD (14+ chars).');
}

const app = express();
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(express.json({ limit: '32kb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'Too many login attempts. Try again later.' }
});
const createLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false
});

const sessions = new Map();

async function bootstrapAdmin() {
  const username = String(process.env.OWNER_USERNAME || process.env.ADMIN_USERNAME).trim().toLowerCase();
  const passwordHash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 12);
  await pool.query(
    `INSERT INTO users(username,password_hash,role,status)
     VALUES($1,$2,'admin','active')
     ON CONFLICT(username) DO NOTHING`,
    [username, passwordHash]
  );
}

app.get('/health', (_req, res) => res.json({ ok: true, service: 't-inverted-unified-backend' }));

// Existing Zentrix HTML form submits username/password as URL-encoded fields to POST /auth.
app.post('/auth', loginLimiter, async (req, res) => {
  try {
    const username = String(req.body.username || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const result = await pool.query(
      'SELECT id, username, password_hash, role, status FROM users WHERE username=$1',
      [username]
    );
    const user = result.rows[0];
    const valid = user && user.status === 'active' && await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.redirect('/?msg=Invalid%20username%20or%20password&type=error');
    setSessionCookie(res, signToken(user));
    return res.redirect(user.role === 'admin' ? '/admin' : '/dashboard');
  } catch (error) {
    console.error('HTML login error:', error.message);
    return res.redirect('/?msg=Login%20temporarily%20unavailable&type=error');
  }
});

app.post('/api/auth/login', loginLimiter, async (req, res) => {
  try {
    const username = String(req.body.username || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const result = await pool.query(
      'SELECT id, username, password_hash, role, status FROM users WHERE username=$1',
      [username]
    );
    const user = result.rows[0];
    const valid = user && user.status === 'active' && await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid username or password.' });
    setSessionCookie(res, signToken(user));
    res.json({ ok: true, user: { id: user.id, username: user.username, role: user.role } });
  } catch (error) {
    console.error('API login error:', error.message);
    res.status(500).json({ error: 'Login temporarily unavailable.' });
  }
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  res.json({ user: { id: req.user.id, username: req.user.username, role: req.user.role, telegramId: req.user.telegram_id } });
});
app.post('/api/auth/logout', (_req, res) => {
  res.clearCookie('ti_session', { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/' });
  res.json({ ok: true });
});
app.get('/logout', (_req, res) => {
  res.clearCookie('ti_session', { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/' });
  res.redirect('/');
});

// Admin user management: admins can create user accounts, assign Telegram ID, suspend/reactivate, reset passwords, and delete.
app.get('/api/admin/users', requireAuth, requireAdmin, async (_req, res) => {
  const result = await pool.query(
    `SELECT id, username, role, status, telegram_id, created_at
     FROM users ORDER BY created_at DESC`
  );
  res.json({ users: result.rows });
});

app.post('/api/admin/users', requireAuth, requireAdmin, createLimiter, async (req, res) => {
  try {
    const username = String(req.body.username || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const telegramId = req.body.telegramId ? String(req.body.telegramId).trim() : null;
    if (!/^[a-z0-9_.-]{3,32}$/.test(username)) return res.status(400).json({ error: 'Username must be 3-32 characters: letters, numbers, dot, underscore or hyphen.' });
    if (password.length < 12 || password.length > 128) return res.status(400).json({ error: 'Password must be 12-128 characters.' });
    if (telegramId && !/^\d{5,20}$/.test(telegramId)) return res.status(400).json({ error: 'Telegram ID must contain 5-20 digits.' });
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      `INSERT INTO users(username,password_hash,role,status,telegram_id)
       VALUES($1,$2,'user','active',$3)
       RETURNING id,username,role,status,telegram_id,created_at`,
      [username, hash, telegramId]
    );
    res.status(201).json({ ok: true, user: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'Username or Telegram ID is already in use.' });
    console.error('Create user error:', error.message);
    res.status(500).json({ error: 'Could not create user.' });
  }
});

app.patch('/api/admin/users/:id', requireAuth, requireAdmin, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid user ID.' });
  const status = req.body.status;
  const telegramId = req.body.telegramId;
  if (status !== undefined && !['active','suspended'].includes(status)) return res.status(400).json({ error: 'Invalid status.' });
  if (telegramId !== undefined && telegramId !== null && !/^\d{5,20}$/.test(String(telegramId))) return res.status(400).json({ error: 'Invalid Telegram ID.' });
  const result = await pool.query(
    `UPDATE users SET
       status=COALESCE($2,status),
       telegram_id=CASE WHEN $3::boolean THEN $4 ELSE telegram_id END,
       updated_at=NOW()
     WHERE id=$1 AND role='user'
     RETURNING id,username,role,status,telegram_id,created_at`,
    [id, status || null, telegramId !== undefined, telegramId === null || telegramId === '' ? null : String(telegramId)]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'User not found.' });
  res.json({ ok: true, user: result.rows[0] });
});

app.post('/api/admin/users/:id/reset-password', requireAuth, requireAdmin, async (req, res) => {
  const id = Number(req.params.id);
  const password = String(req.body.password || '');
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid user ID.' });
  if (password.length < 12 || password.length > 128) return res.status(400).json({ error: 'Password must be 12-128 characters.' });
  const hash = await bcrypt.hash(password, 12);
  const result = await pool.query(
    `UPDATE users SET password_hash=$2,updated_at=NOW() WHERE id=$1 AND role='user' RETURNING id,username`,
    [id, hash]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'User not found.' });
  res.json({ ok: true, message: 'Password reset.' });
});

app.delete('/api/admin/users/:id', requireAuth, requireAdmin, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid user ID.' });
  const result = await pool.query("DELETE FROM users WHERE id=$1 AND role='user' RETURNING id", [id]);
  if (!result.rowCount) return res.status(404).json({ error: 'User not found.' });
  res.json({ ok: true });
});

// WhatsApp socket registry is in-memory; bot bridge repopulates it after reconnect/restart.
function registerSession({ id, ownerId, phone, sock, connected = true }) {
  if (!id || !sock) throw new Error('Session id and socket are required.');
  sessions.set(String(id), { ownerId: String(ownerId || ''), phone: String(phone || ''), sock, connected: Boolean(connected), connectedAt: connected ? new Date().toISOString() : null });
}
function unregisterSession(id) {
  const entry = sessions.get(String(id));
  if (entry) entry.connected = false;
}

app.get('/api/status', requireAuth, async (req, res) => {
  const owned = [...sessions.values()].filter(s => s.connected && (req.user.role === 'admin' || (req.user.telegram_id && s.ownerId === req.user.telegram_id)));
  res.json({ ok: true, connectedSessions: owned.length });
});
app.get('/api/sessions', requireAuth, async (req, res) => {
  const list = [...sessions.entries()]
    .filter(([, s]) => req.user.role === 'admin' || (req.user.telegram_id && s.ownerId === req.user.telegram_id))
    .map(([id, s]) => ({ id, phone: s.phone, connected: s.connected, connectedAt: s.connectedAt }));
  res.json({ sessions: list });
});
app.post('/api/send/text', requireAuth, async (req, res) => {
  try {
    const { sessionId, target, text } = req.body || {};
    if (!sessionId || !target || !text) return res.status(400).json({ error: 'sessionId, target and text are required.' });
    const session = sessions.get(String(sessionId));
    if (!session || !session.connected || !session.sock) return res.status(404).json({ error: 'Connected session not found.' });
    const isOwner = req.user.role === 'admin' || (req.user.telegram_id && session.ownerId === req.user.telegram_id);
    if (!isOwner) return res.status(403).json({ error: 'You do not own this WhatsApp session.' });
    const result = await sendSafeText(session.sock, target, text);
    res.json({ ok: true, messageId: result?.key?.id || null });
  } catch (error) {
    res.status(400).json({ error: String(error.message || 'Send failed').slice(0, 250) });
  }
});

app.get('/dashboard', requireAuth, (_req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/admin', requireAuth, requireAdmin, (_req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));

app.use((err, _req, res, _next) => {
  console.error('Request error:', err.message);
  res.status(500).json({ error: 'Internal server error.' });
});

async function startBackend() {
  await initDb();
  await bootstrapAdmin();
  const port = Number(process.env.PORT || 3000);
  const host = process.env.HOST || '0.0.0.0';
  return app.listen(port, host, () => console.log(`[TOYIN WEB BUG] Unified backend listening on ${host}:${port}`));
}
if (require.main === module) startBackend().catch(err => { console.error(err); process.exit(1); });

module.exports = { app, sessions, registerSession, unregisterSession, startBackend };
