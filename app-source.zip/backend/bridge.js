'use strict';

// Keep this bridge in the same Node process as the existing WhatsApp socket manager.
// Register only after a socket is connected/open.
const backend = require('./server');

function registerWhatsAppSocket(telegramId, phoneNumber, sock) {
  const id = `${telegramId}-${phoneNumber}`;
  backend.registerSession({ id, ownerId: String(telegramId), phone: String(phoneNumber), sock, connected: true });
  return id;
}
function markWhatsAppSocketDisconnected(telegramId, phoneNumber) {
  backend.unregisterSession(`${telegramId}-${phoneNumber}`);
}
module.exports = { registerWhatsAppSocket, markWhatsAppSocketDisconnected };
