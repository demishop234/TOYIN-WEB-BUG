# TOYIN WEB BUG · Unified Accounts Backend

This build provides one username/password account system for both the TOYIN WEB BUG login website and the TOYIN WEB BUG web dashboard.

## What is included

- Original TOYIN WEB BUG login page and its downloaded local assets under `backend/public/`.
- `POST /auth` accepts the existing TOYIN WEB BUG form's `username` and `password` fields.
- `GET /dashboard` is the authenticated user dashboard.
- `GET /admin` is the admin-only account management panel.
- PostgreSQL database stores usernames, bcrypt password hashes, roles, account status, Telegram IDs and creation dates.
- Admin can create users, optionally assign a Telegram numeric ID, suspend/reactivate accounts, reset passwords and delete accounts.
- Same-origin HTTP-only login cookie shared by the TOYIN WEB BUG page, admin panel and user dashboard.
- Authenticated API endpoints for login, logout, account profile, session listing and safe single text sends.
- Bot session access is limited to admin or the account whose assigned Telegram ID matches the registered WhatsApp socket owner ID.

## Deployment layout

Deploy this backend and the existing bot in **one Railway Node service** if you want the web API to use the live WhatsApp sockets. Copy the `backend/` directory into the root of the original bot project. Merge this ZIP's dependencies into the existing package.json; do not overwrite the original bot's dependencies or scripts. Set the root package start command to start your original bot and the backend in the same Node process.

For a simple standalone test of only this web backend, `npm start` runs the web backend, but it will not have WhatsApp sockets until the bot bridge is integrated.

## Railway setup

1. Create a Railway project.
2. Add a PostgreSQL service.
3. Add a Node.js service using the combined bot/backend repository.
4. Add variables to the Node service:
   - `DATABASE_URL` = Railway Postgres reference variable `${{Postgres.DATABASE_URL }}` (use your actual Railway database service name).
   - `OWNER_USERNAME` = any owner username you choose (takes priority over `ADMIN_USERNAME`).
   - `ADMIN_USERNAME` = optional compatibility alias for the owner username.
   - `DEVELOPER_USERNAME` = configurable developer username metadata.
   - `ADMIN_PASSWORD` = a unique password of at least 14 characters.
   - `JWT_SECRET` = a randomly generated secret of at least 64 characters.
   - `NODE_ENV` = `production`.
   - `PGSSL` = `true`.
5. Set the persistent volume for the existing bot's session directory; the exact mount path must match the existing bot's session storage path.
6. Deploy. The first boot creates the database table and initial admin account if that username does not already exist.

The admin account is created from environment variables only on first insert. Changing `ADMIN_PASSWORD` later does not overwrite an existing admin password; use a database admin workflow or implement a deliberate password rotation.

## URLs on the same Railway domain

- `/` — TOYIN WEB BUG login page.
- `/auth` — existing HTML form POST endpoint.
- `/admin` — admin user-management panel (admin role only).
- `/dashboard` — user dashboard.
- `/api/auth/me` — current account.
- `/api/admin/users` — admin user management API.

Do not deploy the TOYIN WEB BUG frontend on a separate origin if you want to use this simple HTTP-only cookie setup. Serving it from this same backend domain is simplest and avoids CORS/cookie configuration.

## Create accounts

Log in as the owner at `/` using `OWNER_USERNAME` (or `ADMIN_USERNAME`) and `ADMIN_PASSWORD`. The successful admin login redirects to `/admin`. Create users there with:
- username (3-32 lowercase letters/numbers/dot/underscore/hyphen),
- password (12-128 characters),
- optional Telegram numeric ID.

Users log in at `/` with their own username/password and are redirected to `/dashboard`.

## Connect the existing WhatsApp bot

This backend's `backend/bridge.js` exports `registerWhatsAppSocket` and `markWhatsAppSocketDisconnected`. In the existing `rentbot.js`, add:

```js
const { registerWhatsAppSocket, markWhatsAppSocketDisconnected } = require('./backend/bridge');
```

At the exact point where the WhatsApp socket has successfully opened, register it using the Telegram ID and phone number already associated with that session:

```js
registerWhatsAppSocket(telegramId, phoneNumber, sock);
```

When that socket closes/logs out:

```js
markWhatsAppSocketDisconnected(telegramId, phoneNumber);
```

The `telegramId` must match the Telegram ID assigned to the user's account in the admin panel. Do not register a socket before it is open. The exact variable names and insertion points must be checked in your actual `rentbot.js`; do not paste the example blindly.

In the original `index.js`, start the backend once after loading the existing bot modules:

```js
const safeBackend = require('./backend/server');
safeBackend.startBackend();
```

Avoid starting a second copy if the bot already starts an HTTP server.

## Security

- Passwords are stored as bcrypt hashes, never plaintext.
- Login attempts are rate-limited.
- Cookies are HTTP-only, same-site lax and secure in production.
- Admin endpoints require an authenticated admin role.
- Users cannot create accounts or grant themselves admin privileges.
- Users only see/send through sessions whose registered Telegram owner ID matches their assigned Telegram ID.
- Safe text sends are limited to 4,000 characters and one send per recipient per 1.5 seconds.
- No crash/freeze payloads, malformed protocol messages, spam loops, or arbitrary raw relay endpoints.
- Use HTTPS. Never publish `.env`, database credentials, JWT secret, bot tokens or WhatsApp session files.

## Important limits

This ZIP is the unified account backend and TOYIN WEB BUG frontend bundle. It is not yet a fully integrated replacement for the original bot ZIP: socket registration and backend startup must be inserted into the existing bot at the verified connection lifecycle locations. Existing Telegram bot commands still use their current Telegram access checks; this web login does not automatically replace Telegram command authorization.


## Branding
The login page, admin panel and user dashboard are branded **TOYIN WEB BUG** and display **Powered by Master Toyin**. Set `OWNER_USERNAME` and `DEVELOPER_USERNAME` in Railway Variables; both can be changed without editing source code. The developer username is currently configuration metadata and does not grant admin privileges.
